from django.shortcuts import render
from elasticsearch import Elasticsearch
from .forms import SearchForm



def search(request):
    # Specify your Elasticsearch host
    es = Elasticsearch(hosts=["http://localhost:9200"])  # Add your Elasticsearch host URL here
    
    query = ""
    results = []

    if request.method == 'POST':
        query = request.POST.get('query', '')

        # Elasticsearch search query
        search_results = es.search(index="pubmed_index", body={
            "query": {
                "match": {
                    "content": query
                }
            }
        })
        
        # Flatten the results and remove the underscores
        for hit in search_results['hits']['hits']:
            result = hit['_source']
            result['id'] = hit['_id']  # Optional: Include the document ID
            results.append(result)
    
    generated_answer = """
Schizophrenia treatment has seen notable advancements in recent years, focusing on both pharmacological and non-pharmacological interventions.

Pharmacological Treatments:
Novel Antipsychotics: Recent studies have introduced medications like Lumateperone, which show efficacy in managing schizophrenia symptoms with fewer side effects, such as reduced metabolic impact.
Targeting Glutamate Systems: Research highlights the potential of drugs that modulate NMDA receptor activity, addressing cognitive deficits and negative symptoms more effectively.
Personalized Medicine: Advances in pharmacogenomics are paving the way for tailoring antipsychotic treatments based on genetic profiles, improving efficacy and reducing adverse effects.

Non-Pharmacological Approaches:
Cognitive Remediation Therapy: Enhanced digital tools are being used to improve cognitive functioning in patients with schizophrenia, complementing pharmacological treatments.
Neurostimulation Techniques: Techniques such as transcranial magnetic stimulation (TMS) are being explored for their role in alleviating treatment-resistant symptoms.

Integrated Care Models:
Holistic approaches combining medication, therapy, and community support are showing significant improvements in long-term outcomes. Digital health platforms are increasingly being used to monitor adherence and provide real-time support.

Future Directions:
Research into biomarkers and neuroimaging is aiding early diagnosis and more targeted interventions.
Emerging psychedelic-assisted therapies are being studied for their potential to reset neural pathways implicated in schizophrenia.

For further insights, consider reviewing recent papers from The Lancet Psychiatry and Nature Reviews Neuroscience, which delve into these developments in detail.
"""
    
    # Print the generated answer to the backend console
    print(generated_answer)

    # Initialize the search form with the query if it was posted
    form = SearchForm(initial={'query': query})

    # Render the search form and the results (if any)
    return render(request, 'search/search_form.html', {'form': form, 'results': results})
